﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class View_Tree
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(View_Tree))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveCurrentViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveTreeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CurrentTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeWithTimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsPNGFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveLegendToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveDiagramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportDistributionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.LoadResultToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToplogyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MostLikelyStatesOnlyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisplayMostMLSInCenterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeyStatesOnlyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EventNodesOnlyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.IncreaseTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwapSubtreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwapWholeTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.GoToToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EventModelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UseSingleAreaModelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TimeBox = New System.Windows.Forms.TextBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.FromParents = New System.Windows.Forms.CheckBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.SingleClade = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Showlegend = New System.Windows.Forms.CheckBox()
        Me.Showline = New System.Windows.Forms.CheckBox()
        Me.ShowPoint = New System.Windows.Forms.CheckBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl2.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage8.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(300, 300)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(477, 481)
        Me.Panel1.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ViewToolStripMenuItem, Me.EventModelToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(692, 25)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadResultToolStripMenuItem, Me.SaveCurrentViewToolStripMenuItem, Me.SaveInfoToolStripMenuItem, Me.SaveTreeToolStripMenuItem1, Me.SaveAsPNGFileToolStripMenuItem, Me.ExportDistributionToolStripMenuItem, Me.ToolStripSeparator3, Me.LoadResultToolStripMenuItem1})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(39, 21)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'LoadResultToolStripMenuItem
        '
        Me.LoadResultToolStripMenuItem.Name = "LoadResultToolStripMenuItem"
        Me.LoadResultToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.LoadResultToolStripMenuItem.Text = "Save Result"
        '
        'SaveCurrentViewToolStripMenuItem
        '
        Me.SaveCurrentViewToolStripMenuItem.BackColor = System.Drawing.SystemColors.Info
        Me.SaveCurrentViewToolStripMenuItem.Name = "SaveCurrentViewToolStripMenuItem"
        Me.SaveCurrentViewToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SaveCurrentViewToolStripMenuItem.Text = "Save Current View"
        '
        'SaveInfoToolStripMenuItem
        '
        Me.SaveInfoToolStripMenuItem.Name = "SaveInfoToolStripMenuItem"
        Me.SaveInfoToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SaveInfoToolStripMenuItem.Text = "Save Info"
        '
        'SaveTreeToolStripMenuItem1
        '
        Me.SaveTreeToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CurrentTreeToolStripMenuItem, Me.TreeWithTimeToolStripMenuItem})
        Me.SaveTreeToolStripMenuItem1.Name = "SaveTreeToolStripMenuItem1"
        Me.SaveTreeToolStripMenuItem1.Size = New System.Drawing.Size(181, 22)
        Me.SaveTreeToolStripMenuItem1.Text = "Export Tree"
        '
        'CurrentTreeToolStripMenuItem
        '
        Me.CurrentTreeToolStripMenuItem.Name = "CurrentTreeToolStripMenuItem"
        Me.CurrentTreeToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.CurrentTreeToolStripMenuItem.Text = "Phylip Tree"
        '
        'TreeWithTimeToolStripMenuItem
        '
        Me.TreeWithTimeToolStripMenuItem.Name = "TreeWithTimeToolStripMenuItem"
        Me.TreeWithTimeToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.TreeWithTimeToolStripMenuItem.Text = "Tree With Time"
        '
        'SaveAsPNGFileToolStripMenuItem
        '
        Me.SaveAsPNGFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveTreeToolStripMenuItem, Me.SaveLegendToolStripMenuItem, Me.SaveDiagramToolStripMenuItem})
        Me.SaveAsPNGFileToolStripMenuItem.Name = "SaveAsPNGFileToolStripMenuItem"
        Me.SaveAsPNGFileToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.SaveAsPNGFileToolStripMenuItem.Text = "Export Graphic"
        '
        'SaveTreeToolStripMenuItem
        '
        Me.SaveTreeToolStripMenuItem.Name = "SaveTreeToolStripMenuItem"
        Me.SaveTreeToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.SaveTreeToolStripMenuItem.Text = "Export Tree"
        '
        'SaveLegendToolStripMenuItem
        '
        Me.SaveLegendToolStripMenuItem.Name = "SaveLegendToolStripMenuItem"
        Me.SaveLegendToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.SaveLegendToolStripMenuItem.Text = "Export Legend"
        '
        'SaveDiagramToolStripMenuItem
        '
        Me.SaveDiagramToolStripMenuItem.Name = "SaveDiagramToolStripMenuItem"
        Me.SaveDiagramToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.SaveDiagramToolStripMenuItem.Text = "Export Diagram"
        '
        'ExportDistributionToolStripMenuItem
        '
        Me.ExportDistributionToolStripMenuItem.Name = "ExportDistributionToolStripMenuItem"
        Me.ExportDistributionToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.ExportDistributionToolStripMenuItem.Text = "Export State"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(178, 6)
        '
        'LoadResultToolStripMenuItem1
        '
        Me.LoadResultToolStripMenuItem1.Name = "LoadResultToolStripMenuItem1"
        Me.LoadResultToolStripMenuItem1.Size = New System.Drawing.Size(181, 22)
        Me.LoadResultToolStripMenuItem1.Text = "Load Result"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OptionToolStripMenuItem, Me.RefreshToolStripMenuItem, Me.ToolStripSeparator1, Me.ToplogyToolStripMenuItem, Me.MostLikelyStatesOnlyToolStripMenuItem, Me.DisplayMostMLSInCenterToolStripMenuItem, Me.KeyStatesOnlyToolStripMenuItem, Me.EventNodesOnlyToolStripMenuItem, Me.ToolStripSeparator2, Me.IncreaseTreeToolStripMenuItem, Me.SwapSubtreeToolStripMenuItem, Me.SwapWholeTreeToolStripMenuItem, Me.ToolStripSeparator4, Me.GoToToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(47, 21)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'OptionToolStripMenuItem
        '
        Me.OptionToolStripMenuItem.Name = "OptionToolStripMenuItem"
        Me.OptionToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.OptionToolStripMenuItem.Text = "Option"
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(249, 6)
        '
        'ToplogyToolStripMenuItem
        '
        Me.ToplogyToolStripMenuItem.CheckOnClick = True
        Me.ToplogyToolStripMenuItem.Name = "ToplogyToolStripMenuItem"
        Me.ToplogyToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ToplogyToolStripMenuItem.Text = "Topology Only"
        '
        'MostLikelyStatesOnlyToolStripMenuItem
        '
        Me.MostLikelyStatesOnlyToolStripMenuItem.CheckOnClick = True
        Me.MostLikelyStatesOnlyToolStripMenuItem.Name = "MostLikelyStatesOnlyToolStripMenuItem"
        Me.MostLikelyStatesOnlyToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.MostLikelyStatesOnlyToolStripMenuItem.Text = "Most Likely States (MLS) Only "
        '
        'DisplayMostMLSInCenterToolStripMenuItem
        '
        Me.DisplayMostMLSInCenterToolStripMenuItem.CheckOnClick = True
        Me.DisplayMostMLSInCenterToolStripMenuItem.Name = "DisplayMostMLSInCenterToolStripMenuItem"
        Me.DisplayMostMLSInCenterToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.DisplayMostMLSInCenterToolStripMenuItem.Text = "Display MLS in center"
        '
        'KeyStatesOnlyToolStripMenuItem
        '
        Me.KeyStatesOnlyToolStripMenuItem.CheckOnClick = True
        Me.KeyStatesOnlyToolStripMenuItem.Enabled = False
        Me.KeyStatesOnlyToolStripMenuItem.Name = "KeyStatesOnlyToolStripMenuItem"
        Me.KeyStatesOnlyToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.KeyStatesOnlyToolStripMenuItem.Text = "Key Nodes Only"
        '
        'EventNodesOnlyToolStripMenuItem
        '
        Me.EventNodesOnlyToolStripMenuItem.CheckOnClick = True
        Me.EventNodesOnlyToolStripMenuItem.Enabled = False
        Me.EventNodesOnlyToolStripMenuItem.Name = "EventNodesOnlyToolStripMenuItem"
        Me.EventNodesOnlyToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.EventNodesOnlyToolStripMenuItem.Text = "Event Nodes Only"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(249, 6)
        '
        'IncreaseTreeToolStripMenuItem
        '
        Me.IncreaseTreeToolStripMenuItem.BackColor = System.Drawing.SystemColors.Info
        Me.IncreaseTreeToolStripMenuItem.Name = "IncreaseTreeToolStripMenuItem"
        Me.IncreaseTreeToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.IncreaseTreeToolStripMenuItem.Text = "Rearrange Tree"
        '
        'SwapSubtreeToolStripMenuItem
        '
        Me.SwapSubtreeToolStripMenuItem.Name = "SwapSubtreeToolStripMenuItem"
        Me.SwapSubtreeToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.SwapSubtreeToolStripMenuItem.Text = "Swap Subtree"
        '
        'SwapWholeTreeToolStripMenuItem
        '
        Me.SwapWholeTreeToolStripMenuItem.Name = "SwapWholeTreeToolStripMenuItem"
        Me.SwapWholeTreeToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.SwapWholeTreeToolStripMenuItem.Text = "Swap Whole Tree"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(249, 6)
        '
        'GoToToolStripMenuItem
        '
        Me.GoToToolStripMenuItem.Name = "GoToToolStripMenuItem"
        Me.GoToToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.GoToToolStripMenuItem.Text = "Most Likely Reconstruction"
        '
        'EventModelToolStripMenuItem
        '
        Me.EventModelToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UseSingleAreaModelToolStripMenuItem})
        Me.EventModelToolStripMenuItem.Name = "EventModelToolStripMenuItem"
        Me.EventModelToolStripMenuItem.Size = New System.Drawing.Size(93, 21)
        Me.EventModelToolStripMenuItem.Text = "Event Model"
        Me.EventModelToolStripMenuItem.Visible = False
        '
        'UseSingleAreaModelToolStripMenuItem
        '
        Me.UseSingleAreaModelToolStripMenuItem.Checked = True
        Me.UseSingleAreaModelToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.UseSingleAreaModelToolStripMenuItem.Name = "UseSingleAreaModelToolStripMenuItem"
        Me.UseSingleAreaModelToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.UseSingleAreaModelToolStripMenuItem.Text = "Use Single Area Model"
        '
        'ListBox1
        '
        Me.ListBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 15
        Me.ListBox1.Location = New System.Drawing.Point(0, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBox1.Size = New System.Drawing.Size(197, 154)
        Me.ListBox1.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(192, 256)
        Me.Panel2.TabIndex = 4
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(160, 134)
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(0, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(205, 476)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.ListBox1)
        Me.TabPage1.Controls.Add(Me.TabControl3)
        Me.TabPage1.Controls.Add(Me.RadioButton2)
        Me.TabPage1.Controls.Add(Me.RadioButton1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(197, 448)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "List"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabControl3
        '
        Me.TabControl3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TabControl3.Controls.Add(Me.TabPage6)
        Me.TabControl3.Controls.Add(Me.TabPage7)
        Me.TabControl3.Location = New System.Drawing.Point(1, 175)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(200, 270)
        Me.TabControl3.TabIndex = 6
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.Panel2)
        Me.TabPage6.Location = New System.Drawing.Point(4, 24)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(192, 242)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "Legned"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.ListView1)
        Me.TabPage7.Location = New System.Drawing.Point(4, 24)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(192, 242)
        Me.TabPage7.TabIndex = 1
        Me.TabPage7.Text = "Color"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.LabelWrap = False
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.MultiSelect = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(192, 252)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'RadioButton2
        '
        Me.RadioButton2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Enabled = False
        Me.RadioButton2.Location = New System.Drawing.Point(99, 154)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(87, 19)
        Me.RadioButton2.TabIndex = 5
        Me.RadioButton2.Text = "Single Area"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(5, 153)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(86, 19)
        Me.RadioButton1.TabIndex = 5
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Multi-Areas"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TextBox1)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(197, 448)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Information"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Location = New System.Drawing.Point(0, 0)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(197, 369)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.WordWrap = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.CheckBox7)
        Me.GroupBox2.Controls.Add(Me.CheckBox6)
        Me.GroupBox2.Controls.Add(Me.CheckBox5)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 375)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(191, 70)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Highlight event"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(95, 42)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Global Info"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(4, 45)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(78, 19)
        Me.CheckBox7.TabIndex = 2
        Me.CheckBox7.Text = "Extinction"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(95, 20)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(83, 19)
        Me.CheckBox6.TabIndex = 1
        Me.CheckBox6.Text = "Vicariance"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(4, 20)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(80, 19)
        Me.CheckBox5.TabIndex = 0
        Me.CheckBox5.Text = "Dispersal"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.ComboBox2)
        Me.TabPage3.Controls.Add(Me.TimeBox)
        Me.TabPage3.Controls.Add(Me.CheckBox8)
        Me.TabPage3.Controls.Add(Me.Button2)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.DataGridView1)
        Me.TabPage3.Controls.Add(Me.FromParents)
        Me.TabPage3.Controls.Add(Me.TextBox3)
        Me.TabPage3.Controls.Add(Me.NumericUpDown3)
        Me.TabPage3.Controls.Add(Me.SingleClade)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(197, 448)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Time"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        Me.ComboBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(69, 420)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(54, 23)
        Me.ComboBox2.TabIndex = 18
        Me.ComboBox2.Visible = False
        '
        'TimeBox
        '
        Me.TimeBox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TimeBox.Location = New System.Drawing.Point(127, 393)
        Me.TimeBox.Name = "TimeBox"
        Me.TimeBox.Size = New System.Drawing.Size(67, 21)
        Me.TimeBox.TabIndex = 19
        Me.TimeBox.Text = "0"
        '
        'CheckBox8
        '
        Me.CheckBox8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Checked = True
        Me.CheckBox8.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox8.Location = New System.Drawing.Point(3, 423)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(72, 19)
        Me.CheckBox8.TabIndex = 9
        Me.CheckBox8.Text = "Reverse"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button2.Location = New System.Drawing.Point(127, 420)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(67, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Calculate"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(0, 396)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(126, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Time of the root node:"
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowTemplate.Height = 23
        Me.DataGridView1.Size = New System.Drawing.Size(194, 387)
        Me.DataGridView1.TabIndex = 0
        '
        'FromParents
        '
        Me.FromParents.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.FromParents.AutoSize = True
        Me.FromParents.Location = New System.Drawing.Point(8, 317)
        Me.FromParents.Name = "FromParents"
        Me.FromParents.Size = New System.Drawing.Size(208, 19)
        Me.FromParents.TabIndex = 17
        Me.FromParents.Text = "Events happened on parent node"
        Me.FromParents.UseVisualStyleBackColor = True
        Me.FromParents.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TextBox3.Location = New System.Drawing.Point(108, 290)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(67, 21)
        Me.TextBox3.TabIndex = 19
        Me.TextBox3.Text = "1"
        Me.TextBox3.Visible = False
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.NumericUpDown3.Location = New System.Drawing.Point(127, 340)
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {0, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(48, 21)
        Me.NumericUpDown3.TabIndex = 15
        Me.NumericUpDown3.Visible = False
        '
        'SingleClade
        '
        Me.SingleClade.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SingleClade.AutoSize = True
        Me.SingleClade.Location = New System.Drawing.Point(8, 292)
        Me.SingleClade.Name = "SingleClade"
        Me.SingleClade.Size = New System.Drawing.Size(97, 19)
        Me.SingleClade.TabIndex = 16
        Me.SingleClade.Text = "Single Clade"
        Me.SingleClade.UseVisualStyleBackColor = True
        Me.SingleClade.Visible = False
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 344)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 15)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Revise node density:"
        Me.Label3.Visible = False
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NumericUpDown1.Location = New System.Drawing.Point(543, 27)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(41, 21)
        Me.NumericUpDown1.TabIndex = 100
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(584, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 15)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Y Spacing"
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(481, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 15)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "X Spacing"
        '
        'NumericUpDown4
        '
        Me.NumericUpDown4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NumericUpDown4.Location = New System.Drawing.Point(645, 27)
        Me.NumericUpDown4.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Size = New System.Drawing.Size(41, 21)
        Me.NumericUpDown4.TabIndex = 100
        Me.NumericUpDown4.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(1, 508)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(205, 23)
        Me.ProgressBar1.TabIndex = 14
        '
        'TabControl2
        '
        Me.TabControl2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Location = New System.Drawing.Point(207, 27)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(485, 509)
        Me.TabControl2.TabIndex = 7
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Panel1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 24)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(477, 481)
        Me.TabPage4.TabIndex = 0
        Me.TabPage4.Text = "Tree"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Showlegend)
        Me.TabPage5.Controls.Add(Me.Showline)
        Me.TabPage5.Controls.Add(Me.ShowPoint)
        Me.TabPage5.Controls.Add(Me.ComboBox1)
        Me.TabPage5.Controls.Add(Me.PictureBox3)
        Me.TabPage5.Controls.Add(Me.TextBox2)
        Me.TabPage5.Location = New System.Drawing.Point(4, 24)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(477, 481)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "Diagram"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Showlegend
        '
        Me.Showlegend.AutoSize = True
        Me.Showlegend.Checked = True
        Me.Showlegend.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Showlegend.Location = New System.Drawing.Point(269, 5)
        Me.Showlegend.Name = "Showlegend"
        Me.Showlegend.Size = New System.Drawing.Size(98, 19)
        Me.Showlegend.TabIndex = 14
        Me.Showlegend.Text = "Show legend"
        Me.Showlegend.UseVisualStyleBackColor = True
        '
        'Showline
        '
        Me.Showline.AutoSize = True
        Me.Showline.Checked = True
        Me.Showline.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Showline.Location = New System.Drawing.Point(187, 5)
        Me.Showline.Name = "Showline"
        Me.Showline.Size = New System.Drawing.Size(84, 19)
        Me.Showline.TabIndex = 13
        Me.Showline.Text = "Show Line"
        Me.Showline.UseVisualStyleBackColor = True
        '
        'ShowPoint
        '
        Me.ShowPoint.AutoSize = True
        Me.ShowPoint.Location = New System.Drawing.Point(100, 5)
        Me.ShowPoint.Name = "ShowPoint"
        Me.ShowPoint.Size = New System.Drawing.Size(88, 19)
        Me.ShowPoint.TabIndex = 13
        Me.ShowPoint.Text = "Show Point"
        Me.ShowPoint.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(3, 3)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(91, 23)
        Me.ComboBox1.TabIndex = 2
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(474, 368)
        Me.PictureBox3.TabIndex = 1
        Me.PictureBox3.TabStop = False
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.Location = New System.Drawing.Point(3, 374)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox2.Size = New System.Drawing.Size(471, 104)
        Me.TextBox2.TabIndex = 0
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.RichTextBox1)
        Me.TabPage8.Location = New System.Drawing.Point(4, 24)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(477, 481)
        Me.TabPage8.TabIndex = 2
        Me.TabPage8.Text = "Supplement"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox1.Location = New System.Drawing.Point(0, 0)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(477, 481)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = ""
        '
        'View_Tree
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(692, 533)
        Me.Controls.Add(Me.NumericUpDown4)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "View_Tree"
        Me.Text = "Tree View"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage8.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadResultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsPNGFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveLegendToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadResultToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RefreshToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents SaveInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
	Friend WithEvents Button2 As System.Windows.Forms.Button
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
	Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
	Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
	Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
	Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
	Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
	Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents ToplogyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents MostLikelyStatesOnlyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents KeyStatesOnlyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents EventNodesOnlyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
	Friend WithEvents SaveDiagramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents NumericUpDown4 As System.Windows.Forms.NumericUpDown
	Friend WithEvents ShowPoint As System.Windows.Forms.CheckBox
	Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
	Friend WithEvents NumericUpDown3 As System.Windows.Forms.NumericUpDown
	Friend WithEvents SingleClade As System.Windows.Forms.CheckBox
	Friend WithEvents FromParents As System.Windows.Forms.CheckBox
	Friend WithEvents Showline As System.Windows.Forms.CheckBox
	Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
	Friend WithEvents TimeBox As System.Windows.Forms.TextBox
	Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents EventModelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents UseSingleAreaModelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents SwapSubtreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents SaveTreeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents Showlegend As System.Windows.Forms.CheckBox
	Friend WithEvents CurrentTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents TreeWithTimeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ExportDistributionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents SwapWholeTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents GoToToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
	Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
	Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
	Friend WithEvents ListView1 As System.Windows.Forms.ListView
	Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
	Friend WithEvents Button1 As System.Windows.Forms.Button
	Friend WithEvents DisplayMostMLSInCenterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
	Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
	Friend WithEvents IncreaseTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents SaveCurrentViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents DataGridView1 As DataGridView
End Class
