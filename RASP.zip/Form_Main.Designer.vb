<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form_Main
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Main))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadTreesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadTreesDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QuickLoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadOneTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddTreesDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadDistrutionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadFinalTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadConsensusTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MakeFinalTreeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveDistributionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormatedTreeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeDataSetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RandomTreesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.CloseDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GraphicToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PiePictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TracerViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TraitsViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProcessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModelTestToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BioGeoBEARSToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.StatisticalMethodsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatisticalDECSDECToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatisticalDIVALIKEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OriginalMethodsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DispersalExtinctionCladogenesisDECToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DIVALIKEInBiogenBEARSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TraitsEvolutionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BayesianBinaryMCMCBBMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommandBuilderForBayesTraitsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChromosomeEvolutionChromEvolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComparisonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeClusterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatesVsTreesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OtherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InstallReinstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BioGeoBEARSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.FindRscriptexeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.RemoveOutgroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CombineResultsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OmittedTaxaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.AddTreeLengthToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeTimeMultiplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.DatingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DPPAnalysisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BatchToolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DebugToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BurninBox = New System.Windows.Forms.TextBox()
        Me.FinalTreeBox = New System.Windows.Forms.TextBox()
        Me.CmdBox = New System.Windows.Forms.RichTextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TreeInfo = New System.Windows.Forms.RichTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TreeBox_P = New System.Windows.Forms.TextBox()
        Me.RandomTextBox = New System.Windows.Forms.TextBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.DIVA_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Bayes_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.statebox = New System.Windows.Forms.RichTextBox()
        Me.Main_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Lag_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.DPP_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.BGB_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.Check_Package_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.GraphicToolStripMenuItem, Me.ProcessToolStripMenuItem, Me.ComparisonToolStripMenuItem, Me.OtherToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(792, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadTreesToolStripMenuItem, Me.LoadDistrutionToolStripMenuItem, Me.LoadFinalTreeToolStripMenuItem, Me.OpenResultToolStripMenuItem, Me.ToolStripSeparator2, Me.SaveToolStripMenuItem, Me.ExportToolStripMenuItem, Me.ToolStripSeparator3, Me.CloseDataToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'LoadTreesToolStripMenuItem
        '
        Me.LoadTreesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadTreesDataToolStripMenuItem, Me.QuickLoadToolStripMenuItem, Me.LoadOneTreeToolStripMenuItem, Me.AddTreesDataToolStripMenuItem})
        Me.LoadTreesToolStripMenuItem.Name = "LoadTreesToolStripMenuItem"
        Me.LoadTreesToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.LoadTreesToolStripMenuItem.Text = "Load Trees"
        '
        'LoadTreesDataToolStripMenuItem
        '
        Me.LoadTreesDataToolStripMenuItem.Name = "LoadTreesDataToolStripMenuItem"
        Me.LoadTreesDataToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.LoadTreesDataToolStripMenuItem.Text = "Load Trees (More Format)"
        '
        'QuickLoadToolStripMenuItem
        '
        Me.QuickLoadToolStripMenuItem.Name = "QuickLoadToolStripMenuItem"
        Me.QuickLoadToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.QuickLoadToolStripMenuItem.Text = "Quick Load (Beast, Mrbayes)"
        '
        'LoadOneTreeToolStripMenuItem
        '
        Me.LoadOneTreeToolStripMenuItem.Enabled = False
        Me.LoadOneTreeToolStripMenuItem.Name = "LoadOneTreeToolStripMenuItem"
        Me.LoadOneTreeToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.LoadOneTreeToolStripMenuItem.Text = "Load Single Tree"
        Me.LoadOneTreeToolStripMenuItem.Visible = False
        '
        'AddTreesDataToolStripMenuItem
        '
        Me.AddTreesDataToolStripMenuItem.Enabled = False
        Me.AddTreesDataToolStripMenuItem.Name = "AddTreesDataToolStripMenuItem"
        Me.AddTreesDataToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.AddTreesDataToolStripMenuItem.Text = "Add Trees"
        '
        'LoadDistrutionToolStripMenuItem
        '
        Me.LoadDistrutionToolStripMenuItem.Enabled = False
        Me.LoadDistrutionToolStripMenuItem.Name = "LoadDistrutionToolStripMenuItem"
        Me.LoadDistrutionToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.LoadDistrutionToolStripMenuItem.Text = "Load States (Distributions)"
        '
        'LoadFinalTreeToolStripMenuItem
        '
        Me.LoadFinalTreeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadConsensusTreeToolStripMenuItem, Me.MakeFinalTreeToolStripMenuItem1})
        Me.LoadFinalTreeToolStripMenuItem.Enabled = False
        Me.LoadFinalTreeToolStripMenuItem.Name = "LoadFinalTreeToolStripMenuItem"
        Me.LoadFinalTreeToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.LoadFinalTreeToolStripMenuItem.Text = "Load Condensed Tree"
        '
        'LoadConsensusTreeToolStripMenuItem
        '
        Me.LoadConsensusTreeToolStripMenuItem.Name = "LoadConsensusTreeToolStripMenuItem"
        Me.LoadConsensusTreeToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.LoadConsensusTreeToolStripMenuItem.Text = "Load User-specified Tree"
        '
        'MakeFinalTreeToolStripMenuItem1
        '
        Me.MakeFinalTreeToolStripMenuItem1.Name = "MakeFinalTreeToolStripMenuItem1"
        Me.MakeFinalTreeToolStripMenuItem1.Size = New System.Drawing.Size(221, 22)
        Me.MakeFinalTreeToolStripMenuItem1.Text = "Compute Condensed Tree"
        '
        'OpenResultToolStripMenuItem
        '
        Me.OpenResultToolStripMenuItem.Name = "OpenResultToolStripMenuItem"
        Me.OpenResultToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.OpenResultToolStripMenuItem.Text = "Load Result"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(218, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveResultToolStripMenuItem, Me.SaveDistributionToolStripMenuItem, Me.SaveLogToolStripMenuItem})
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'SaveResultToolStripMenuItem
        '
        Me.SaveResultToolStripMenuItem.Name = "SaveResultToolStripMenuItem"
        Me.SaveResultToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.SaveResultToolStripMenuItem.Text = "Save Results"
        '
        'SaveDistributionToolStripMenuItem
        '
        Me.SaveDistributionToolStripMenuItem.Name = "SaveDistributionToolStripMenuItem"
        Me.SaveDistributionToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.SaveDistributionToolStripMenuItem.Text = "Save States"
        '
        'SaveLogToolStripMenuItem
        '
        Me.SaveLogToolStripMenuItem.Name = "SaveLogToolStripMenuItem"
        Me.SaveLogToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.SaveLogToolStripMenuItem.Text = "Save Logs"
        '
        'ExportToolStripMenuItem
        '
        Me.ExportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormatedTreeToolStripMenuItem, Me.TreeDataSetToolStripMenuItem, Me.RandomTreesToolStripMenuItem})
        Me.ExportToolStripMenuItem.Name = "ExportToolStripMenuItem"
        Me.ExportToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.ExportToolStripMenuItem.Text = "Export Trees"
        '
        'FormatedTreeToolStripMenuItem
        '
        Me.FormatedTreeToolStripMenuItem.Enabled = False
        Me.FormatedTreeToolStripMenuItem.Name = "FormatedTreeToolStripMenuItem"
        Me.FormatedTreeToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.FormatedTreeToolStripMenuItem.Text = "Condensed Tree"
        '
        'TreeDataSetToolStripMenuItem
        '
        Me.TreeDataSetToolStripMenuItem.Enabled = False
        Me.TreeDataSetToolStripMenuItem.Name = "TreeDataSetToolStripMenuItem"
        Me.TreeDataSetToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.TreeDataSetToolStripMenuItem.Text = "Discarded Trees"
        '
        'RandomTreesToolStripMenuItem
        '
        Me.RandomTreesToolStripMenuItem.Enabled = False
        Me.RandomTreesToolStripMenuItem.Name = "RandomTreesToolStripMenuItem"
        Me.RandomTreesToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.RandomTreesToolStripMenuItem.Text = "Random Trees"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(218, 6)
        '
        'CloseDataToolStripMenuItem
        '
        Me.CloseDataToolStripMenuItem.Enabled = False
        Me.CloseDataToolStripMenuItem.Name = "CloseDataToolStripMenuItem"
        Me.CloseDataToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.CloseDataToolStripMenuItem.Text = "Close Current Data"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
        Me.ExitToolStripMenuItem.Text = "Exit RASP"
        '
        'GraphicToolStripMenuItem
        '
        Me.GraphicToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TreeViewToolStripMenuItem, Me.PiePictureToolStripMenuItem, Me.TracerViewToolStripMenuItem, Me.TraitsViewToolStripMenuItem})
        Me.GraphicToolStripMenuItem.Name = "GraphicToolStripMenuItem"
        Me.GraphicToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.GraphicToolStripMenuItem.Text = "Graphic"
        '
        'TreeViewToolStripMenuItem
        '
        Me.TreeViewToolStripMenuItem.Name = "TreeViewToolStripMenuItem"
        Me.TreeViewToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.TreeViewToolStripMenuItem.Text = "Tree View"
        '
        'PiePictureToolStripMenuItem
        '
        Me.PiePictureToolStripMenuItem.Name = "PiePictureToolStripMenuItem"
        Me.PiePictureToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.PiePictureToolStripMenuItem.Text = "Node View"
        '
        'TracerViewToolStripMenuItem
        '
        Me.TracerViewToolStripMenuItem.Enabled = False
        Me.TracerViewToolStripMenuItem.Name = "TracerViewToolStripMenuItem"
        Me.TracerViewToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.TracerViewToolStripMenuItem.Text = "Tracer View"
        '
        'TraitsViewToolStripMenuItem
        '
        Me.TraitsViewToolStripMenuItem.Name = "TraitsViewToolStripMenuItem"
        Me.TraitsViewToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.TraitsViewToolStripMenuItem.Text = "State View"
        '
        'ProcessToolStripMenuItem
        '
        Me.ProcessToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ModelTestToolStripMenuItem, Me.ToolStripSeparator8, Me.StatisticalMethodsToolStripMenuItem, Me.OriginalMethodsToolStripMenuItem, Me.TraitsEvolutionToolStripMenuItem})
        Me.ProcessToolStripMenuItem.Name = "ProcessToolStripMenuItem"
        Me.ProcessToolStripMenuItem.Size = New System.Drawing.Size(102, 20)
        Me.ProcessToolStripMenuItem.Text = "Reconstruction"
        '
        'ModelTestToolStripMenuItem
        '
        Me.ModelTestToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BioGeoBEARSToolStripMenuItem2})
        Me.ModelTestToolStripMenuItem.Enabled = False
        Me.ModelTestToolStripMenuItem.Name = "ModelTestToolStripMenuItem"
        Me.ModelTestToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.ModelTestToolStripMenuItem.Text = "Model Test"
        '
        'BioGeoBEARSToolStripMenuItem2
        '
        Me.BioGeoBEARSToolStripMenuItem2.Name = "BioGeoBEARSToolStripMenuItem2"
        Me.BioGeoBEARSToolStripMenuItem2.Size = New System.Drawing.Size(308, 22)
        Me.BioGeoBEARSToolStripMenuItem2.Text = "Compare Six Models Using BioGeoBEARS"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(183, 6)
        '
        'StatisticalMethodsToolStripMenuItem
        '
        Me.StatisticalMethodsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem, Me.StatisticalDECSDECToolStripMenuItem, Me.StatisticalDIVALIKEToolStripMenuItem})
        Me.StatisticalMethodsToolStripMenuItem.Enabled = False
        Me.StatisticalMethodsToolStripMenuItem.Name = "StatisticalMethodsToolStripMenuItem"
        Me.StatisticalMethodsToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.StatisticalMethodsToolStripMenuItem.Text = "On Trees "
        '
        'StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem
        '
        Me.StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem.Name = "StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem"
        Me.StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem.Size = New System.Drawing.Size(435, 22)
        Me.StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem.Text = "Statistical Dispersal-Vicariance Analysis (S-DIVA)"
        '
        'StatisticalDECSDECToolStripMenuItem
        '
        Me.StatisticalDECSDECToolStripMenuItem.Name = "StatisticalDECSDECToolStripMenuItem"
        Me.StatisticalDECSDECToolStripMenuItem.Size = New System.Drawing.Size(435, 22)
        Me.StatisticalDECSDECToolStripMenuItem.Text = "Statistical Dispersal-Extinction-Cladogenesis (S-DEC)"
        '
        'StatisticalDIVALIKEToolStripMenuItem
        '
        Me.StatisticalDIVALIKEToolStripMenuItem.Name = "StatisticalDIVALIKEToolStripMenuItem"
        Me.StatisticalDIVALIKEToolStripMenuItem.Size = New System.Drawing.Size(435, 22)
        Me.StatisticalDIVALIKEToolStripMenuItem.Text = "Statistical DIVALIKE/DEC/BAYAREALIKE in BioGeoBEARS (S-BGB)"
        '
        'OriginalMethodsToolStripMenuItem
        '
        Me.OriginalMethodsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DispersalExtinctionCladogenesisDECToolStripMenuItem, Me.BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem, Me.DIVALIKEInBiogenBEARSToolStripMenuItem})
        Me.OriginalMethodsToolStripMenuItem.Enabled = False
        Me.OriginalMethodsToolStripMenuItem.Name = "OriginalMethodsToolStripMenuItem"
        Me.OriginalMethodsToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.OriginalMethodsToolStripMenuItem.Text = "On Condensed Tree"
        '
        'DispersalExtinctionCladogenesisDECToolStripMenuItem
        '
        Me.DispersalExtinctionCladogenesisDECToolStripMenuItem.Name = "DispersalExtinctionCladogenesisDECToolStripMenuItem"
        Me.DispersalExtinctionCladogenesisDECToolStripMenuItem.Size = New System.Drawing.Size(333, 22)
        Me.DispersalExtinctionCladogenesisDECToolStripMenuItem.Text = "Dispersal-Extinction-Cladogenesis (DEC)"
        '
        'BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem
        '
        Me.BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem.Name = "BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem"
        Me.BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem.Size = New System.Drawing.Size(333, 22)
        Me.BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem.Text = "Bayesian inference for discrete Areas (BayArea)"
        '
        'DIVALIKEInBiogenBEARSToolStripMenuItem
        '
        Me.DIVALIKEInBiogenBEARSToolStripMenuItem.Name = "DIVALIKEInBiogenBEARSToolStripMenuItem"
        Me.DIVALIKEInBiogenBEARSToolStripMenuItem.Size = New System.Drawing.Size(333, 22)
        Me.DIVALIKEInBiogenBEARSToolStripMenuItem.Text = "DIVALIKE/DEC/BAYAREALIKE in BioGeoBEARS"
        '
        'TraitsEvolutionToolStripMenuItem
        '
        Me.TraitsEvolutionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BayesianBinaryMCMCBBMToolStripMenuItem, Me.CommandBuilderForBayesTraitsToolStripMenuItem, Me.ChromosomeEvolutionChromEvolToolStripMenuItem})
        Me.TraitsEvolutionToolStripMenuItem.Enabled = False
        Me.TraitsEvolutionToolStripMenuItem.Name = "TraitsEvolutionToolStripMenuItem"
        Me.TraitsEvolutionToolStripMenuItem.Size = New System.Drawing.Size(186, 22)
        Me.TraitsEvolutionToolStripMenuItem.Text = "Traits Evolution"
        '
        'BayesianBinaryMCMCBBMToolStripMenuItem
        '
        Me.BayesianBinaryMCMCBBMToolStripMenuItem.Name = "BayesianBinaryMCMCBBMToolStripMenuItem"
        Me.BayesianBinaryMCMCBBMToolStripMenuItem.Size = New System.Drawing.Size(276, 22)
        Me.BayesianBinaryMCMCBBMToolStripMenuItem.Text = "Bayesian Binary MCMC (BBM)"
        '
        'CommandBuilderForBayesTraitsToolStripMenuItem
        '
        Me.CommandBuilderForBayesTraitsToolStripMenuItem.Name = "CommandBuilderForBayesTraitsToolStripMenuItem"
        Me.CommandBuilderForBayesTraitsToolStripMenuItem.Size = New System.Drawing.Size(276, 22)
        Me.CommandBuilderForBayesTraitsToolStripMenuItem.Text = "Command Builder for BayesTraits"
        '
        'ChromosomeEvolutionChromEvolToolStripMenuItem
        '
        Me.ChromosomeEvolutionChromEvolToolStripMenuItem.Name = "ChromosomeEvolutionChromEvolToolStripMenuItem"
        Me.ChromosomeEvolutionChromEvolToolStripMenuItem.Size = New System.Drawing.Size(276, 22)
        Me.ChromosomeEvolutionChromEvolToolStripMenuItem.Text = "Chromosome Evolution (ChromEvol)"
        '
        'ComparisonToolStripMenuItem
        '
        Me.ComparisonToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TreeClusterToolStripMenuItem, Me.StatesVsTreesToolStripMenuItem})
        Me.ComparisonToolStripMenuItem.Name = "ComparisonToolStripMenuItem"
        Me.ComparisonToolStripMenuItem.Size = New System.Drawing.Size(88, 20)
        Me.ComparisonToolStripMenuItem.Text = "Comparison"
        '
        'TreeClusterToolStripMenuItem
        '
        Me.TreeClusterToolStripMenuItem.Name = "TreeClusterToolStripMenuItem"
        Me.TreeClusterToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TreeClusterToolStripMenuItem.Text = "Trees Cluster"
        '
        'StatesVsTreesToolStripMenuItem
        '
        Me.StatesVsTreesToolStripMenuItem.Name = "StatesVsTreesToolStripMenuItem"
        Me.StatesVsTreesToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.StatesVsTreesToolStripMenuItem.Text = "State vs. Trees"
        '
        'OtherToolStripMenuItem
        '
        Me.OtherToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InstallReinstallToolStripMenuItem, Me.ToolStripSeparator7, Me.RemoveOutgroupToolStripMenuItem, Me.CombineResultsToolStripMenuItem, Me.OmittedTaxaToolStripMenuItem1, Me.ToolStripSeparator9, Me.AddTreeLengthToolStripMenuItem, Me.TreeTimeMultiplierToolStripMenuItem, Me.ToolStripSeparator1, Me.DatingToolStripMenuItem, Me.BatchToolToolStripMenuItem})
        Me.OtherToolStripMenuItem.Name = "OtherToolStripMenuItem"
        Me.OtherToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.OtherToolStripMenuItem.Text = "Tools"
        '
        'InstallReinstallToolStripMenuItem
        '
        Me.InstallReinstallToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BioGeoBEARSToolStripMenuItem1, Me.ToolStripSeparator4, Me.FindRscriptexeToolStripMenuItem})
        Me.InstallReinstallToolStripMenuItem.Name = "InstallReinstallToolStripMenuItem"
        Me.InstallReinstallToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.InstallReinstallToolStripMenuItem.Text = "Install 3rd Party"
        '
        'BioGeoBEARSToolStripMenuItem1
        '
        Me.BioGeoBEARSToolStripMenuItem1.Name = "BioGeoBEARSToolStripMenuItem1"
        Me.BioGeoBEARSToolStripMenuItem1.Size = New System.Drawing.Size(172, 22)
        Me.BioGeoBEARSToolStripMenuItem1.Text = "R packages"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(169, 6)
        '
        'FindRscriptexeToolStripMenuItem
        '
        Me.FindRscriptexeToolStripMenuItem.Name = "FindRscriptexeToolStripMenuItem"
        Me.FindRscriptexeToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.FindRscriptexeToolStripMenuItem.Text = "Select Rscript.exe"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(212, 6)
        '
        'RemoveOutgroupToolStripMenuItem
        '
        Me.RemoveOutgroupToolStripMenuItem.Name = "RemoveOutgroupToolStripMenuItem"
        Me.RemoveOutgroupToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.RemoveOutgroupToolStripMenuItem.Text = "Remove Selected Groups"
        '
        'CombineResultsToolStripMenuItem
        '
        Me.CombineResultsToolStripMenuItem.Name = "CombineResultsToolStripMenuItem"
        Me.CombineResultsToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.CombineResultsToolStripMenuItem.Text = "Combine Results"
        '
        'OmittedTaxaToolStripMenuItem1
        '
        Me.OmittedTaxaToolStripMenuItem1.Name = "OmittedTaxaToolStripMenuItem1"
        Me.OmittedTaxaToolStripMenuItem1.Size = New System.Drawing.Size(215, 22)
        Me.OmittedTaxaToolStripMenuItem1.Text = "Add Omitted Groups"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(212, 6)
        '
        'AddTreeLengthToolStripMenuItem
        '
        Me.AddTreeLengthToolStripMenuItem.Name = "AddTreeLengthToolStripMenuItem"
        Me.AddTreeLengthToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.AddTreeLengthToolStripMenuItem.Text = "Add Branch Length"
        '
        'TreeTimeMultiplierToolStripMenuItem
        '
        Me.TreeTimeMultiplierToolStripMenuItem.Name = "TreeTimeMultiplierToolStripMenuItem"
        Me.TreeTimeMultiplierToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.TreeTimeMultiplierToolStripMenuItem.Text = "Branch Length Multiplier "
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(212, 6)
        Me.ToolStripSeparator1.Visible = False
        '
        'DatingToolStripMenuItem
        '
        Me.DatingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadDataToolStripMenuItem, Me.DPPAnalysisToolStripMenuItem})
        Me.DatingToolStripMenuItem.Name = "DatingToolStripMenuItem"
        Me.DatingToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.DatingToolStripMenuItem.Text = "Molecular Clock"
        Me.DatingToolStripMenuItem.Visible = False
        '
        'LoadDataToolStripMenuItem
        '
        Me.LoadDataToolStripMenuItem.Name = "LoadDataToolStripMenuItem"
        Me.LoadDataToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.LoadDataToolStripMenuItem.Text = "Load Data Matrix"
        '
        'DPPAnalysisToolStripMenuItem
        '
        Me.DPPAnalysisToolStripMenuItem.Name = "DPPAnalysisToolStripMenuItem"
        Me.DPPAnalysisToolStripMenuItem.Size = New System.Drawing.Size(245, 22)
        Me.DPPAnalysisToolStripMenuItem.Text = "Dirichlet Process Prior Analysis"
        '
        'BatchToolToolStripMenuItem
        '
        Me.BatchToolToolStripMenuItem.Name = "BatchToolToolStripMenuItem"
        Me.BatchToolToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.BatchToolToolStripMenuItem.Text = "Batch Tool"
        Me.BatchToolToolStripMenuItem.Visible = False
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.DebugToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'DebugToolStripMenuItem
        '
        Me.DebugToolStripMenuItem.Name = "DebugToolStripMenuItem"
        Me.DebugToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.DebugToolStripMenuItem.Text = "Debug"
        '
        'TreeBox
        '
        Me.TreeBox.BackColor = System.Drawing.Color.White
        Me.TreeBox.Location = New System.Drawing.Point(139, 20)
        Me.TreeBox.Name = "TreeBox"
        Me.TreeBox.ReadOnly = True
        Me.TreeBox.Size = New System.Drawing.Size(88, 21)
        Me.TreeBox.TabIndex = 2
        Me.TreeBox.Text = "0"
        Me.TreeBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Amount of trees:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 15)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Discard trees:"
        '
        'BurninBox
        '
        Me.BurninBox.BackColor = System.Drawing.Color.White
        Me.BurninBox.Location = New System.Drawing.Point(139, 74)
        Me.BurninBox.Name = "BurninBox"
        Me.BurninBox.Size = New System.Drawing.Size(88, 21)
        Me.BurninBox.TabIndex = 5
        Me.BurninBox.Text = "0"
        Me.BurninBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'FinalTreeBox
        '
        Me.FinalTreeBox.Location = New System.Drawing.Point(11, 152)
        Me.FinalTreeBox.Name = "FinalTreeBox"
        Me.FinalTreeBox.ReadOnly = True
        Me.FinalTreeBox.Size = New System.Drawing.Size(216, 21)
        Me.FinalTreeBox.TabIndex = 14
        '
        'CmdBox
        '
        Me.CmdBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CmdBox.BackColor = System.Drawing.Color.White
        Me.CmdBox.ForeColor = System.Drawing.Color.Black
        Me.CmdBox.Location = New System.Drawing.Point(0, 384)
        Me.CmdBox.Name = "CmdBox"
        Me.CmdBox.Size = New System.Drawing.Size(548, 155)
        Me.CmdBox.TabIndex = 15
        Me.CmdBox.Text = ""
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(0, 36)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 23
        Me.DataGridView1.Size = New System.Drawing.Size(548, 345)
        Me.DataGridView1.TabIndex = 18
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.TreeInfo)
        Me.GroupBox1.Controls.Add(Me.FinalTreeBox)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.TreeBox_P)
        Me.GroupBox1.Controls.Add(Me.RandomTextBox)
        Me.GroupBox1.Controls.Add(Me.CheckBox3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TreeBox)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.BurninBox)
        Me.GroupBox1.Location = New System.Drawing.Point(554, 33)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(234, 472)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tree Option"
        '
        'Button1
        '
        Me.Button1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Location = New System.Drawing.Point(12, 440)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(212, 26)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "CHECK STATUS"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TreeInfo
        '
        Me.TreeInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TreeInfo.BackColor = System.Drawing.SystemColors.Info
        Me.TreeInfo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TreeInfo.Location = New System.Drawing.Point(7, 179)
        Me.TreeInfo.Name = "TreeInfo"
        Me.TreeInfo.ReadOnly = True
        Me.TreeInfo.Size = New System.Drawing.Size(221, 255)
        Me.TreeInfo.TabIndex = 44
        Me.TreeInfo.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 15)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Binary trees:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 134)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(147, 15)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "Current Condensed Tree:"
        '
        'TreeBox_P
        '
        Me.TreeBox_P.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TreeBox_P.BackColor = System.Drawing.Color.White
        Me.TreeBox_P.Location = New System.Drawing.Point(139, 47)
        Me.TreeBox_P.Name = "TreeBox_P"
        Me.TreeBox_P.ReadOnly = True
        Me.TreeBox_P.Size = New System.Drawing.Size(88, 21)
        Me.TreeBox_P.TabIndex = 32
        Me.TreeBox_P.Text = "0"
        Me.TreeBox_P.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'RandomTextBox
        '
        Me.RandomTextBox.Location = New System.Drawing.Point(139, 101)
        Me.RandomTextBox.Name = "RandomTextBox"
        Me.RandomTextBox.ReadOnly = True
        Me.RandomTextBox.Size = New System.Drawing.Size(88, 21)
        Me.RandomTextBox.TabIndex = 22
        Me.RandomTextBox.Text = "100"
        Me.RandomTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Checked = True
        Me.CheckBox3.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox3.Location = New System.Drawing.Point(12, 103)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(105, 19)
        Me.CheckBox3.TabIndex = 21
        Me.CheckBox3.Text = "Random trees"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(0, 545)
        Me.ProgressBar1.Maximum = 10000
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(790, 28)
        Me.ProgressBar1.TabIndex = 21
        '
        'DIVA_Timer
        '
        Me.DIVA_Timer.Interval = 1000
        '
        'Bayes_Timer
        '
        Me.Bayes_Timer.Interval = 1000
        '
        'statebox
        '
        Me.statebox.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.statebox.BackColor = System.Drawing.SystemColors.Info
        Me.statebox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.statebox.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.statebox.Location = New System.Drawing.Point(554, 511)
        Me.statebox.Name = "statebox"
        Me.statebox.ReadOnly = True
        Me.statebox.Size = New System.Drawing.Size(234, 28)
        Me.statebox.TabIndex = 22
        Me.statebox.Text = ""
        '
        'Main_Timer
        '
        Me.Main_Timer.Interval = 1000
        '
        'Lag_Timer
        '
        Me.Lag_Timer.Interval = 1000
        '
        'DPP_Timer
        '
        Me.DPP_Timer.Interval = 1000
        '
        'BGB_Timer
        '
        Me.BGB_Timer.Interval = 1000
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(359, 6)
        '
        'Form_Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 573)
        Me.Controls.Add(Me.statebox)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.CmdBox)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form_Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "RASP (Reconstruct Ancestral State in Phylogenies)"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadTreesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreeBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BurninBox As System.Windows.Forms.TextBox
    Friend WithEvents FinalTreeBox As System.Windows.Forms.TextBox
    Friend WithEvents ExportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadDistrutionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadFinalTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CmdBox As System.Windows.Forms.RichTextBox
    Friend WithEvents GraphicToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadConsensusTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents ProcessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents RandomTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents FormatedTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreeViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PiePictureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MakeFinalTreeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OtherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DIVA_Timer As System.Windows.Forms.Timer
    Friend WithEvents LoadTreesDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddTreesDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreeBox_P As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents OmittedTaxaToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Bayes_Timer As System.Windows.Forms.Timer
    Friend WithEvents statebox As System.Windows.Forms.RichTextBox
    Friend WithEvents Main_Timer As System.Windows.Forms.Timer
    Friend WithEvents QuickLoadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadOneTreeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveResultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveLogToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveDistributionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenResultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Lag_Timer As System.Windows.Forms.Timer
    Friend WithEvents DPP_Timer As System.Windows.Forms.Timer
    Friend WithEvents DatingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DPPAnalysisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CombineResultsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RandomTreesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TracerViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DebugToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveOutgroupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreeDataSetToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TreeInfo As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TraitsViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BatchToolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BGB_Timer As System.Windows.Forms.Timer
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents InstallReinstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BioGeoBEARSToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FindRscriptexeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Check_Package_Timer As System.Windows.Forms.Timer
    Friend WithEvents OriginalMethodsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatisticalMethodsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ModelTestToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DispersalExtinctionCladogenesisDECToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BayesianInferenceForDiscreteAreasBayAreaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DIVALIKEInBiogenBEARSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatisticalDispersalVicarianceAnalysisSDIVAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatisticalDECSDECToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatisticalDIVALIKEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TraitsEvolutionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BayesianBinaryMCMCBBMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommandBuilderForBayesTraitsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChromosomeEvolutionChromEvolToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BioGeoBEARSToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TreeTimeMultiplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AddTreeLengthToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents ComparisonToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TreeClusterToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StatesVsTreesToolStripMenuItem As ToolStripMenuItem
End Class
